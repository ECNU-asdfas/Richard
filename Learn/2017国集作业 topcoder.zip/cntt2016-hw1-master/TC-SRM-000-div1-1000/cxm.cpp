class AB{
public:
  int solve(int a, int b){
    return a + b;
  }
}
