#include <cstring>
#include <algorithm>
#include <cstdio>
#include <utility>
#include <vector>

using std::max;
using std::pair;
using std::vector;
typedef long long ll;
typedef pair<ll,ll> pll;
const int N = 1000;
int _w;

int n;
vector<pll> v[49];

void prelude() {
	for( ll i = 0; i <= N; ++i )
		for( ll j = 0; j <= N; ++j )
			if( i+j <= n ) {
				ll begin = i*5 + j*10;
				ll cnt = n-i-j;
				begin += cnt;
				++cnt;
				v[begin % 49].push_back( pll(begin, begin + cnt * 49) );
			}
}

void solve() {
	ll ans = 0;
	for( int i = 0; i < 49; ++i ) {
		vector<pll> &now = v[i];
		sort(now.begin(), now.end());
		ll right = 0;
		for( int j = 0; j < (int)now.size(); ++j ) {
			ll begin = now[j].first;
			ll end = now[j].second;
			begin = max(begin, right);
			if( begin < end ) {
				ans += (end - begin) / 49;
				right = end;
			}
		}
	}
	printf( "%lld\n", ans );
}

int main() {
	_w = scanf( "%d", &n );
	prelude(), solve();
	return 0;
}
