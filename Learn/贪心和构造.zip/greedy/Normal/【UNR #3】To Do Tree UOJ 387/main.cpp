#include <cstring>
#include <algorithm>
#include <cstdio>
#include <queue>
#include <vector>

using std::vector;
using std::priority_queue;
const int N = 100010;
int _w;

int max( int a, int b ) {
	return a > b ? a : b;
}

int n, m, f[N], dis[N];

namespace G {
	int head[N], nxt[N], to[N], eid;
	void init() {
		eid = 0;
		memset(head, -1, sizeof head);
	}
	void link( int u, int v ) {
		to[eid] = v, nxt[eid] = head[u], head[u] = eid++;
	}
}

void prelude( int u ) {
	using namespace G;
	dis[u] = 0;
	for( int i = head[u]; ~i; i = nxt[i] ) {
		int v = to[i];
		prelude(v);
		dis[u] = max( dis[u], dis[v] + 1 );
	}
}

vector<int> ans[N];
int cnt, q[N], qn;

struct Cmp {
	bool operator()( int i, int j ) const {
		return dis[i] < dis[j];
	}
};
priority_queue<int, vector<int>, Cmp> pq;

void solve() {
	using namespace G;
	q[qn++] = 1;
	while( !pq.empty() || qn ) {
		for( int i = 0; i < qn; ++i )
			pq.push( q[i] );
		qn = 0;
		for( int i = 0; i < m && !pq.empty(); ++i ) {
			int u = pq.top();
			pq.pop();
			ans[cnt].push_back(u);
			for( int e = head[u]; ~e; e = nxt[e] )
				q[qn++] = to[e];
		}
		++cnt;
	}
}

int main() {
	_w = scanf( "%d%d", &n, &m );
	G::init();
	for( int i = 2; i <= n; ++i ) {
		_w = scanf( "%d", f+i );
		G::link( f[i], i );
	}
	prelude(1), solve();
	printf( "%d\n", cnt );
	for( int i = 0; i < cnt; ++i, puts("") ) {
		int sz = (int)ans[i].size();
		printf( "%d ", sz );
		for( int j = 0; j < sz; ++j )
			printf( "%d ", ans[i][j] );
	}
	return 0;
}
