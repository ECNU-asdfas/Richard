#include <bits/stdc++.h>

using namespace std;
typedef long long ll;

int n, a, b, c, d;

int main() {
	scanf( "%d%d%d%d%d", &n, &a, &b, &c, &d );
	--n;
	for( int x = 0; x <= n; ++x ) {
		ll minv = a + (ll)c*x - (ll)d*(n-x);
		ll maxv = a + (ll)d*x - (ll)c*(n-x);
		if( minv <= b && maxv >= b ) {
			puts("YES");
			return 0;
		}
	}
	puts("NO");
	return 0;
}
