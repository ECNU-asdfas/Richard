#include <cstring>
#include <algorithm>
#include <cstdio>

using namespace std;
typedef long long ll;
const int MAXN = 501;
int _w;

int C[MAXN];
void prelude() {
	for( int i = 3; i < MAXN; ++i )
		C[i] = i*(i-1)*(i-2)/6;
}

int a[MAXN], sz, g[MAXN][MAXN];
void fill( int l, int r ) {
	for( int i = l; i <= r; ++i )
		for( int j = l; j <= r; ++j )
			g[i][j] = 1;
}
void solve( int n ) {
	for( int i = MAXN-1; i >= 3; --i )
		while( n >= C[i] )
			n -= C[i], a[sz++] = i;
	int tot = 0;
	for( int i = 0; i < sz; ++i ) {
		fill(tot, tot+a[i]-1);
		tot += a[i];
	}
	printf( "%d\n", tot );
	for( int i = 0; i < tot; ++i ) {
		for( int j = i+1; j < tot; ++j )
			printf( "%d ", g[i][j] );
		puts("");
	}
}

int main() {
	int n;
	_w = scanf( "%d", &n );
	prelude(), solve(n);
	return 0;
}
