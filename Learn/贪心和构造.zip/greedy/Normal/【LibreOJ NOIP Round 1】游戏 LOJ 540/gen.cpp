#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
int _w;

int main() {
	freopen( "in.txt", "r", stdin );
	int n;
	_w = scanf( "%d", &n );
	if( n > 1 ) --n;
	fclose(stdin);
	freopen( "in.txt", "w", stdout );
	printf( "%d\n", n );
	fclose(stdout);
	return 0;
}
