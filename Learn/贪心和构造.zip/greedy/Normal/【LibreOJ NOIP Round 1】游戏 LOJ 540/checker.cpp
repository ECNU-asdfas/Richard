#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
const int MAXN = 501;
int _w;

int n, g[MAXN][MAXN];

int main() {
	freopen( "out.txt", "r", stdin );
	_w = scanf( "%d", &n );
	if( n <= 0 || n > 500 ) return 1;
	for( int i = 0; i < n; ++i )
		for( int j = i+1; j < n; ++j ) {
			_w = scanf( "%d", &g[i][j] );
			g[j][i] = g[i][j];
		}
	fclose(stdin);
	int cnt = 0;
	for( int i = 0; i < n; ++i )
		for( int j = i+1; j < n; ++j )
			for( int k = j+1; k < n; ++k )
				if( g[i][j] && g[j][k] && g[i][k] )
					++cnt;
	freopen( "in.txt", "r", stdin );
	int ans;
	_w = scanf( "%d", &ans );
	if( ans != cnt ) return 1;
	return 0;
}
