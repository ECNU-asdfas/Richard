#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
const int N = 200010;
int _w;

int n, a[N], len[N];

int main() {
	_w = scanf( "%d", &n );
	for( int i = 1; i <= n; ++i )
		_w = scanf( "%d", a+i );
	for( int i = 1; i <= n; ++i ) {
		int x = a[i];
		if( len[x-1] ) len[x] = len[x-1] + 1;
		else len[x] = 1;
	}
	printf( "%d\n", n - *max_element(len+1, len+n+1) );
	return 0;
}
