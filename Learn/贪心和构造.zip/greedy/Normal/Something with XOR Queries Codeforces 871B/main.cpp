#include <bits/stdc++.h>

using namespace std;
const int MAXN = 5010;
int _w;

int n, a0[MAXN], b0[MAXN];

int vis[MAXN];
bool valid( int *a ) {
	for( int i = 0; i < n; ++i ) vis[i] = 0;
	for( int i = 0; i < n; ++i )
		if( a[i] >= n ) return false;
		else ++vis[a[i]];
	for( int i = 0; i < n; ++i )
		if( vis[i] != 1 ) return false;
	return true;
}

int a[MAXN], b[MAXN];
bool check( int x ) {
	a[0] = x;
	for( int i = 1; i < n; ++i )
		a[i] = b0[0] ^ b0[i] ^ a[0];
	if( !valid(a) ) return false;
	b[0] = a[0] ^ a0[0];
	for( int i = 1; i < n; ++i )
		b[i] = a0[0] ^ a0[i] ^ b[0];
	if( !valid(b) ) return false;
	for( int i = 0; i < n; ++i )
		if( b[a[i]] != i ) return false;
	return true;
}

int main() {
	_w = scanf( "%d", &n );
	for( int i = 0; i < n; ++i ) {
		printf( "? 0 %d\n", i );
		fflush(stdout);
		_w = scanf( "%d", a0+i );
	}
	for( int i = 0; i < n; ++i ) {
		printf( "? %d 0\n", i );
		fflush(stdout);
		_w = scanf( "%d", b0+i );
	}
	printf( "!\n" );
	int cnt = 0;
	for( int i = 0; i < n; ++i )
		if( check(i) ) ++cnt;
	printf( "%d\n", cnt );
	for( int i = 0; i < n; ++i )
		if( check(i) ) {
			printf( "%d ", i );
			for( int j = 1; j < n; ++j )
				printf( "%d ", b0[0] ^ b0[j] ^ i );
			break;
		}
	puts("");
	fflush(stdout);
	return 0;
}
