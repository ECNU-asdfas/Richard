#include <bits/stdc++.h>

using namespace std;
const int N = 510;
int _w;

int n, m;
char a[N][N], b[N][N];

void solvea() {
	for( int i = 1; i <= n; ++i )
		for( int j = 1; j <= m; ++j )
			a[i][j] = '.';
	for( int i = 1; i <= n; i += 2 )
		for( int j = 1; j < m; ++j )
			a[i][j] = '#';
	for( int i = 1; i <= n; ++i )
		a[i][1] = '#';
}

void solveb() {
	for( int i = 1; i <= n; ++i )
		for( int j = 1; j <= m; ++j )
			b[i][j] = '.';
	for( int i = 2; i <= n; i += 2 )
		for( int j = 2; j <= m; ++j )
			b[i][j] = '#';
	for( int i = 1; i <= n; ++i )
		b[i][m] = '#';
}

int main() {
	cin >> n >> m;
	solvea(), solveb();
	for( int i = 1; i <= n; ++i )
		for( int j = 1; j <= m; ++j ) {
			char c;
			_w = scanf( " %c", &c );
			if( c == '#' ) a[i][j] = b[i][j] = c;
		}
	for( int i = 1; i <= n; ++i, puts("") )
		for( int j = 1; j <= m; ++j )
			putchar( a[i][j] );
	puts("");
	for( int i = 1; i <= n; ++i, puts("") )
		for( int j = 1; j <= m; ++j )
			putchar( b[i][j] );
	return 0;
}
