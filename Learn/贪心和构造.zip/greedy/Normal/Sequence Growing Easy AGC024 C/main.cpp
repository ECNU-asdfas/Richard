#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
const int N = 200010;
int _w;

int n, a[N], x[N];
ll ans;

int main() {
	_w = scanf( "%d", &n );
	for( int i = 1; i <= n; ++i )
		_w = scanf( "%d", a+i );
	for( int i = n; i >= 1; --i ) {
		x[i] = max(0, x[i+1] - 1);
		if( a[i] < x[i] )
			return puts("-1"), 0;
		else if( a[i] > x[i] ) {
			if( a[i] >= i )
				return puts("-1"), 0;
			else
				ans += a[i], x[i] = a[i];
		}
	}
	cout << ans << endl;
	return 0;
}
