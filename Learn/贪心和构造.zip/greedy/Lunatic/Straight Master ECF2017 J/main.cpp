#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
const int N = 200010;
int _w;

int T, n, a[N];
ll b[N];

bool solve() {
	for( int i = 1; i <= n; ++i )
		if( a[i] ) {
			b[i] = min<ll>( b[i], a[i] );
			a[i] -= (int)b[i];
			b[i+1] += b[i];
			if( a[i] ) {
				if( a[i+1] < a[i] ) return false;
				if( a[i+2] < a[i] ) return false;
				a[i+1] -= a[i];
				a[i+2] -= a[i];
				b[i+3] += a[i];
			}
		}
	return true;
}

int main() {
	_w = scanf( "%d", &T );
	for( int kase = 1; kase <= T; ++kase ) {
		_w = scanf( "%d", &n );
		for( int i = 1; i <= n; ++i ) {
			_w = scanf( "%d", a+i );
			b[i] = 0;
		}
		a[n+1] = a[n+2] = 0;
		printf( "Case #%d: %s\n", kase, solve() ? "Yes" : "No" );
	}
	return 0;
}
