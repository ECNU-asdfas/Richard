#include <cstring>
#include <algorithm>
#include <cstdio>

using std::min;
const int N = 200010;
const int INF = 0x3f3f3f3f;
const int MOD = 1e9+7;
int _w;

int fpow( int a, int b ) {
	int c = 1;
	while(b) {
		if( b & 1 ) c = int(1LL * c * a % MOD);
		a = int(1LL * a * a % MOD);
		b >>= 1;
	}
	return c;
}
int inv( int x ) {
	return fpow(x, MOD-2);
}

int n, x, y, c[N], w[N];
int cmin[N], cnt[N];
int pfmin[N], sfmin[N];

int fac[N];
void prelude() {
	fac[0] = 1;
	for( int i = 1; i < N; ++i )
		fac[i] = int(1LL * fac[i-1] * i % MOD);
}

int main() {
	_w = scanf( "%d%d%d", &n, &x, &y );
	memset(cmin, 0x3f, sizeof cmin);
	memset(pfmin, 0x3f, sizeof pfmin);
	memset(sfmin, 0x3f, sizeof sfmin);
	for( int i = 1; i <= n; ++i ) {
		_w = scanf( "%d%d", c+i, w+i );
		cmin[c[i]] = min( cmin[c[i]], w[i] );
		++cnt[c[i]];
	}
	for( int i = 1; i <= n; ++i )
		pfmin[i] = min( pfmin[i-1], cmin[i] );
	for( int i = n; i >= 1; --i )
		sfmin[i] = min( sfmin[i+1], cmin[i] );
	for( int i = 1; i <= n; ++i ) {
		int t = min( pfmin[c[i]-1], sfmin[c[i]+1] );
		if( t + w[i] > y && w[i] + cmin[c[i]] > x )
			--cnt[c[i]];
	}
	for( int i = 1; i <= n; ++i ) {
		int t = min( pfmin[i-1], sfmin[i+1] );
		if( t + cmin[i] > y ) cnt[i] = 0;
	}
	prelude();
	int ans = 1, tot = 0;
	for( int i = 1; i <= n; ++i ) {
		ans = int(1LL * ans * inv( fac[cnt[i]] ) % MOD);
		tot += cnt[i];
	}
	ans = int(1LL * ans * fac[tot] % MOD);
	printf( "%d\n", ans );
	return 0;
}
