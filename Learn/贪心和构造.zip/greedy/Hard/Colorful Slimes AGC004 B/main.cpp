#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
const int N = 2010;
const ll INFLL = 1e18;
int _w;

int n, x, a[N];

int nxt( int i ) {
	return i == n ? 1 : i+1;
}
int pre( int i ) {
	return i == 1 ? n : i-1;
}

int minv[N][N];
void prelude() {
	for( int i = 1; i <= n; ++i ) {
		minv[i][i] = a[i];
		for( int j = nxt(i); j != i; j = nxt(j) )
			minv[i][j] = min( minv[i][pre(j)], a[j] );
	}
}

void solve() {
	ll ans = INFLL;
	for( int i = 0; i < n; ++i ) {
		ll now = 1LL * i * x;
		for( int j = 1; j <= n; ++j ) {
			int p = j-i;
			p += p <= 0 ? n : 0;
			now += minv[p][j];
		}
		ans = min(ans, now);
	}
	cout << ans << endl;
}

int main() {
	cin >> n >> x;
	for( int i = 1; i <= n; ++i )
		cin >> a[i];
	prelude(), solve();
	return 0;
}
