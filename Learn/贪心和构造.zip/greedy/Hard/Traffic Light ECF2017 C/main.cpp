#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
const int N = 1010;
int _w;

int T, n, a[N], b[N], s[N];

int main() {
	_w = scanf( "%d", &T );
	for( int kase = 1; kase <= T; ++kase ) {
		_w = scanf( "%d", &n );
		int ans = 0;
		for( int i = 0; i <= n; ++i ) {
			_w = scanf( "%d", s+i );
			ans += s[i];
		}
		int maxb = 0;
		for( int i = 1; i <= n; ++i ) {
			_w = scanf( "%d%d", a+i, b+i );
			maxb = max( maxb, b[i] );
		}
		printf( "Case #%d: %d\n", kase, ans + maxb );
	}
	return 0;
}
