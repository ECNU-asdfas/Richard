#include <cstring>
#include <algorithm>
#include <cstdio>

using namespace std;
const int MAXN = 310;
int nowarn;

int n, m, a[MAXN][MAXN], ans;

int vis[MAXN], cnt[MAXN];

int main() {
	nowarn = scanf( "%d%d", &n, &m );
	for( int i = 1; i <= n; ++i )
		for( int j = 1; j <= m; ++j )
			nowarn = scanf( "%d", &a[i][j] );
	ans = n;
	for( int i = 1; i <= m; ++i ) vis[i] = 1;
	for( int t = 0; t < m-1; ++t ) {
		for( int i = 1; i <= m; ++i ) cnt[i] = 0;
		for( int i = 1; i <= n; ++i )
			for( int j = 1; j <= m; ++j ) {
				int k = a[i][j];
				if( vis[k] ) {
					++cnt[k];
					break;
				}
			}
		int p = int(max_element(cnt+1, cnt+m+1) - cnt);
		ans = min(ans, cnt[p]);
		vis[p] = 0;
	}
	printf( "%d\n", ans );
	return 0;
}
