#include <cstring>
#include <algorithm>
#include <cstdio>
#include <queue>

using namespace std;
typedef long long ll;
const int MAXN = 100010;

int n, k;
ll w[MAXN] = {0};

struct Node {
	ll cnt, dep;
	Node():
		cnt(0), dep(0) {}
	Node( ll cnt, ll dep ):
		cnt(cnt), dep(dep) {}
	bool operator<( const Node &rhs ) const {
		if( cnt == rhs.cnt ) return dep > rhs.dep;
		else return cnt > rhs.cnt;
	}
};

priority_queue<Node> pq;

int main() {
	scanf( "%d%d", &n, &k );
	for( int i = 0; i < n; ++i ) scanf( "%lld", w+i );
	while( (n-1)%(k-1) ) ++n;
	for( int i = 0; i < n; ++i ) pq.push( Node(w[i], 0) );
	ll ans = 0;
	while( n > 1 ) {
		Node nod;
		for( int i = 0; i < k; ++i ) {
			Node tmp = pq.top(); pq.pop();
			nod.cnt += tmp.cnt;
			nod.dep = max(nod.dep, tmp.dep+1);
		}
		ans += nod.cnt;
		pq.push(nod);
		n -= k-1;
	}
	printf( "%lld\n", ans );
	printf( "%lld\n", pq.top().dep );
	return 0;
}
