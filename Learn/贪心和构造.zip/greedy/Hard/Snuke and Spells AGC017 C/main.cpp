#include <cstring>
#include <algorithm>
#include <cstdio>

const int N = 200010;
int _w;

int n, m, a[N], ans;
int cnt[N], vis[N];

void ins( int x ) {
	++cnt[x];
	int y = x - cnt[x] + 1;
	if( y > 0 ) {
		++vis[y];
		ans -= vis[y] == 1;
	}
}

void del( int x ) {
	int y = x - cnt[x] + 1;
	--cnt[x];
	if( y > 0 ) {
		--vis[y];
		ans += !vis[y];
	}
}

void prelude() {
	ans = n;
	for( int i = 1; i <= n; ++i )
		ins( a[i] );
}

void modify( int x, int y ) {
	del( a[x] );
	a[x] = y;
	ins( a[x] );
}

int main() {
	_w = scanf( "%d%d", &n, &m );
	for( int i = 1; i <= n; ++i )
		_w = scanf( "%d", a+i );
	prelude();
	while( m-- ) {
		int x, y;
		_w = scanf( "%d%d", &x, &y );
		modify(x, y);
		printf( "%d\n", ans );
	}
	return 0;
}
