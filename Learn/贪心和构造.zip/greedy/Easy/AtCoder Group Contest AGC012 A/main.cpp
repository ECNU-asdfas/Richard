#include <cstring>
#include <algorithm>
#include <cstdio>

using std::sort;
typedef long long ll;
const int N = 1000010;
int _w;

int n, a[N];
ll ans;

int main() {
	_w = scanf( "%d", &n );
	for( int i = 1; i <= n+n+n; ++i )
		_w = scanf( "%d", a+i );
	sort(a+1, a+n+n+n+1);
	for( int i = n+1; i <= n+n+n; i += 2 )
		ans += a[i];
	printf( "%lld\n", ans );
	return 0;
}
