#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
const int N = 1100;
int _w;

int n, m, l[N], r[N];

int main() {
	_w = scanf( "%d%d", &n, &m );
	for( int i = 1; i <= n; ++i )
		putchar( (i & 1) + '0' );
	puts("");
	return 0;
}
