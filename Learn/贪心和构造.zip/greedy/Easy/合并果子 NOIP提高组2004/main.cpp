#include <cstdio>
#include <cmath>
#include <cstring>
#include <algorithm>
#include <string>
#include <iostream>

using namespace std;

void insertsort( int arr[] , int *end , int start )
{
    int temp = arr[ start ];
    int i;
    for( i = start + 1 ; arr + i != end ; ++i )
    {
        if( temp < arr[ i ] )
        {
            arr[ i - 1 ] = temp;
            return;
        }
        else
        {
            arr[ i - 1 ] = arr[ i ];
        }
    }
    if( arr + i == end )
    {
        arr[ i - 1 ] = temp;
    }
}

int main()
{
    int n;
    int arr[ 10001 ];
    int energy = 0;
    scanf( "%d" , &n );
    for( int i = 0 ; i < n ; ++i )
    {
        scanf( "%d" , &arr[ i ] );
    }
    sort( arr , arr + n );
    for( int i = 0 ; i < n - 1 ; ++i )
    {
        arr[ i + 1 ] += arr[ i ];
        arr[ i ] = 0;
        energy += arr[ i + 1 ];
        insertsort( arr , arr + n , i + 1 );
    }
    printf( "%d" , energy );
    return 0;
}

