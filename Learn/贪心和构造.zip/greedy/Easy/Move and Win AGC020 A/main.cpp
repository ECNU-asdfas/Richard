#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
int _w;

int main() {
	int n, a, b;
	cin >> n >> a >> b;
	puts( (b-a-1) & 1 ? "Alice" : "Borys" );
	return 0;
}
